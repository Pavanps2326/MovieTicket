package com.mphasis.eBookStore.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.Domain.Book;
import com.mphasis.Proxy.EBookStoreServiceProxy;

@RestController
public class eBookStoreConsumerContrller {

	@Autowired
	EBookStoreServiceProxy eBookStoreServiceProxy;
	
	@GetMapping("/books")
	public List<Book> getAllBookDetails(){
		return eBookStoreServiceProxy.getAllBookDetails();
	}
}
