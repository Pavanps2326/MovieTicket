package com.mphasis.Proxy;


import java.util.List;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;

import com.mphasis.Domain.Book;

@FeignClient("BookStore")
public interface EBookStoreServiceProxy {
	
	@GetMapping(value="/books",
			produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Book> getAllBookDetails();
}
